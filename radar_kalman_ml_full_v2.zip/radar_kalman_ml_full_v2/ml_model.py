import numpy as np

def _sigmoid(z):
    return 1.0/(1.0+np.exp(-z))

class SimpleLogisticModel:
    def __init__(self, w=None, b=0.0):
        if w is None:
            self.w = np.array([2.0,1.0], float)
        else:
            self.w = np.array(w, float)
        self.b = float(b)

    def predict_proba(self, X):
        X = np.array(X, float)
        z = X @ self.w + self.b
        return _sigmoid(z)

    def predict(self, X, threshold=0.5):
        p = self.predict_proba(X)
        return (p >= threshold).astype(int)

def load_default_model():
    return SimpleLogisticModel()
