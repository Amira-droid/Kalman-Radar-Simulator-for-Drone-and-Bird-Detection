import random
import numpy as np

class KalmanFilter2D:
    def __init__(self, x0, y0, vx0=0.0, vy0=0.0, dt=1.0):
        self.dt = dt
        self.x = np.array([[x0],[y0],[vx0],[vy0]], float)
        self.F = np.array([[1,0,dt,0],[0,1,0,dt],[0,0,1,0],[0,0,0,1]], float)
        self.H = np.array([[1,0,0,0],[0,1,0,0]], float)
        self.P = np.eye(4)*50.0
        self.Q = np.eye(4)*0.01
        self.R = np.eye(2)*5.0

    def predict(self):
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q

    def update(self, z):
        z = np.array(z, float).reshape(2,1)
        y = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        I = np.eye(4)
        self.P = (I - K @ self.H) @ self.P

    @property
    def pos(self):
        return float(self.x[0,0]), float(self.x[1,0])

    def predict_future_positions(self, steps=5):
        preds = []
        xf = self.x.copy()
        for _ in range(steps):
            xf = self.F @ xf
            preds.append((float(xf[0,0]), float(xf[1,0])))
        return preds

class Target:
    def __init__(self, label="drone"):
        self.label = label
        self.x = random.uniform(0,100)
        self.y = random.uniform(0,100)
        self.vx = random.uniform(-1,1)
        self.vy = random.uniform(-1,1)
        self.kf = KalmanFilter2D(self.x,self.y,self.vx,self.vy)
        self.prev_meas = None
        self.jitter_history = []
        self.ml_prob_drone = 0.5

    def step(self):
        self.x += self.vx
        self.y += self.vy
        if self.x < 0 or self.x > 100:
            self.vx *= -1
            self.x = max(0, min(100,self.x))
        if self.y < 0 or self.y > 100:
            self.vy *= -1
            self.y = max(0, min(100,self.y))

        meas_x = self.x + random.gauss(0,2.0)
        meas_y = self.y + random.gauss(0,2.0)

        if self.prev_meas is not None:
            dx = meas_x - self.prev_meas[0]
            dy = meas_y - self.prev_meas[1]
            jitter = (dx*dx + dy*dy)**0.5
            self.jitter_history.append(jitter)
            if len(self.jitter_history) > 20:
                self.jitter_history.pop(0)
        self.prev_meas = (meas_x, meas_y)

        self.kf.predict()
        self.kf.update([meas_x, meas_y])

    @property
    def filtered_position(self):
        return self.kf.pos

    def feature_vector(self):
        if not self.jitter_history:
            return [0.0, 0.0]
        avg_j = sum(self.jitter_history)/len(self.jitter_history)
        max_j = max(self.jitter_history)
        return [avg_j, max_j]

    def future_path(self, steps=5):
        return self.kf.predict_future_positions(steps)

def is_in_forbidden_zone(x,y,zone):
    x0,y0,x1,y1 = zone
    return x0 <= x <= x1 and y0 <= y <= y1
