import numpy as np

def generate_heatmap(targets, grid_size=32):
    """Generate a simple 2D heatmap based on target positions.

    X-axis ~ horizontal airspace position
    Y-axis ~ vertical airspace position
    Brighter / warmer colors = more target energy / activity.
    """
    heatmap = np.zeros((grid_size, grid_size), float)
    xs = np.linspace(0,100,grid_size)
    ys = np.linspace(0,100,grid_size)
    X, Y = np.meshgrid(xs, ys)
    for t in targets:
        x,y = t.filtered_position
        # Different spread / amplitude for drones vs birds (using ground-truth label)
        if t.label == "drone":
            sigma = 5.0
            amp = 2.0
        else:
            sigma = 8.0
            amp = 1.0
        blob = amp * np.exp(-(((X-x)**2 + (Y-y)**2)/(2*sigma**2)))
        heatmap += blob
    if heatmap.max() > 0:
        heatmap /= heatmap.max()
    return heatmap
