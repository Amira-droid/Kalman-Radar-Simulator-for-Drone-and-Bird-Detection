import time
from flask import Flask, jsonify, render_template
from tracker import Target, is_in_forbidden_zone
from radar_sim import generate_heatmap
from ml_model import load_default_model

app = Flask(__name__)
ml_model = load_default_model()

# Three drones and three birds (ground-truth labels)
targets = [
    Target("drone"), Target("drone"), Target("drone"),
    Target("bird"), Target("bird"), Target("bird"),
]

FORBIDDEN_ZONE = (40,40,60,60)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/scene")
def get_scene():
    # Step all targets
    for t in targets:
        t.step()

    # Simple ML probability based on jitter features (used only for info/alert logic)
    features = [t.feature_vector() for t in targets]
    proba = ml_model.predict_proba(features)
    for t,p in zip(targets, proba):
        t.ml_prob_drone = float(p)

    # Counts based on ground-truth labels (what you see: drones vs birds)
    drone_count = sum(1 for t in targets if t.label == "drone")
    bird_count = sum(1 for t in targets if t.label == "bird")

    # Alerts: only when a ground-truth drone enters the restricted zone
    alerts = []
    for t in targets:
        if t.label == "drone":
            fx,fy = t.filtered_position
            if is_in_forbidden_zone(fx,fy,FORBIDDEN_ZONE):
                alerts.append(f"Drone in restricted zone at ({fx:.1f},{fy:.1f})")
    alert_msg = " | ".join(alerts) if alerts else None

    # Future path of first drone (if exists)
    future_path = []
    first_drone = next((t for t in targets if t.label == "drone"), None)
    if first_drone is not None:
        future_path = first_drone.future_path(5)

    # Heatmap using ground-truth labels
    heatmap = generate_heatmap(targets, 32).tolist()

    data = {
        "targets":[
            {
                "label": t.label,  # use ground-truth label for color & legend
                "x": t.filtered_position[0],
                "y": t.filtered_position[1],
                "prob_drone": t.ml_prob_drone,
            } for t in targets
        ],
        "forbidden_zone":{
            "xmin":FORBIDDEN_ZONE[0],
            "ymin":FORBIDDEN_ZONE[1],
            "xmax":FORBIDDEN_ZONE[2],
            "ymax":FORBIDDEN_ZONE[3],
        },
        "counts":{"drone":drone_count,"bird":bird_count},
        "alert":alert_msg,
        "future_path":future_path,
        "heatmap":heatmap,
    }
    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True)
