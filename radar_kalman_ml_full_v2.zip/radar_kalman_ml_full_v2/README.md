
# Radar Airspace Monitor (Kalman + Heatmap)

This version includes:
- Visible drones (red) and birds (blue) using ground-truth labels
- Kalman filter tracking and a clearly marked future path (green dotted line + markers)
- A synthetic airspace heatmap with an interpretation legend
- Restricted zone (red box) and audio alerts when a drone enters it

Run with:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Then open http://127.0.0.1:5000/ in your browser.
